﻿using Google.Protobuf.Protocol;
using System;
using System.Collections.Generic;

namespace Server
{
    [Serializable]
    public class StatData : ILoader<int, StatInfo>
    {
        public List<StatInfo> stats = new List<StatInfo>();

        public Dictionary<int, StatInfo> MakeDict()
        {
            Dictionary<int, StatInfo> dict = new Dictionary<int, StatInfo>();
            foreach (StatInfo stat in stats)
            {
                stat.Hp = stat.MaxHp;
                dict.Add(stat.Level, stat);
            }
            return dict;
        }
    }

    [Serializable]
    public class Skill
    {
        public int id;
        public int level;
        public string name;
        public float damage;
        public float cooldown;
        public SkillState state;
        public ProjectileInfo _pInfo;
    }

    [Serializable]
    public class SkillData : ILoader<int, Skill>
    {
        public List<Skill> skills = new List<Skill>();

        public Dictionary<int, Skill> MakeDict()
        {
            Dictionary<int, Skill> dict = new Dictionary<int, Skill>();
            foreach (Skill skill in skills)
                dict.Add(skill.level, skill);
            return dict;
        }
    }

    public class ProjectileInfo
    {
        public int id;
        public string name;
        public float damage;
        public float cooldown;
        public float speed;
    }
}
