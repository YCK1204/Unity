﻿using System;
using System.IO;

namespace Server
{
    [Serializable]
    public class ServerConfig 
    {
        public string dataPath;
    }


    public class ConfigManager
    {
        public static ServerConfig config { get; private set; }

        public static void LoadConfig()
        {
            string text = File.ReadAllText("config.json");
            config = Newtonsoft.Json.JsonConvert.DeserializeObject<ServerConfig>(text);
        }
    }
}
