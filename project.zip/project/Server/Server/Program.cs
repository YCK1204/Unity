﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using Server.Game;
using Server.Job;
using ServerCore;

namespace Server
{
    class Program
	{
		static Listener _listener = new Listener();
		static List<System.Timers.Timer> timers = new List<System.Timers.Timer>();

		static void TickRoom(GameRoom room, int time = 100)
		{
			var timer = new System.Timers.Timer();
			timer.Interval = time;
			timer.Elapsed += ((s, e) => { room.Update(); });
			timer.AutoReset = true;
			timer.Enabled = true;

			timers.Add(timer);
		}

		static void Main(string[] args)
		{
			ConfigManager.LoadConfig();
			DataManager.LoadData();

			var a = DataManager.StatDict;
			var b = DataManager.SkillDict;
			GameRoom room = GameRoomManager.Instance.Add(0);
			TickRoom(room);

			// DNS (Domain Name System)
			string host = Dns.GetHostName();
			IPHostEntry ipHost = Dns.GetHostEntry(host);
			IPAddress ipAddr = ipHost.AddressList[0];
			IPEndPoint endPoint = new IPEndPoint(ipAddr, 7777);

			_listener.Init(endPoint, () => { return SessionManager.Instance.Generate(); });
			Console.WriteLine("Listening...");

            while (true)
			{
				Thread.Sleep(800);
			}
		}
	}
}
