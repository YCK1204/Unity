﻿using Google.Protobuf.Protocol;
using System;
using System.Collections.Generic;
using System.IO;

namespace Server.Game
{
    public struct Vector2Int
    {
        public int x;
        public int y;

        public Vector2Int(int x, int y) { this.x = x; this.y = y; }
        public static Vector2Int up { get { return new Vector2Int(0, 1); } }
        public static Vector2Int down { get { return new Vector2Int(0, -1); } }
        public static Vector2Int left { get { return new Vector2Int(-1, 0); } }
        public static Vector2Int right { get { return new Vector2Int(1, 0); } }

        public static Vector2Int operator +(Vector2Int a, Vector2Int b)
        {
            return new Vector2Int(a.x + b.x, a.y + b.y);
        }
        public static Vector2Int operator -(Vector2Int a, Vector2Int b)
        {
            return new Vector2Int(a.x - b.x, a.y - b.y);
        }

        public int sqrMagnitude { get { return (int)(x * x + y * y); } }
        public float magnitude { get { return (float)Math.Sqrt(sqrMagnitude); } }
        public int cellDistFromZero { get { return Math.Abs(x) + Math.Abs(y); } }
    }

    public class Map
    {
        public int xMax { get; set; }
        public int xMin { get; set; }
        public int yMax { get; set; }
        public int yMin { get; set; }

        int SizeX { get { return xMax - xMin + 1; } }
        int SizeY { get { return yMax - yMin + 1; } }

        int[] nx = { -1, 0, 1, 0 };
        int[] ny = { 0, 1, 0, -1 };

        public bool[,] _collision;
        public GameObject[,] _objects;

        public List<Vector2Int> FindPath(Vector2Int startPos, Vector2Int destPos, bool _checkObjects = false, int maxCount = 10)
        {
            int[,] steps = new int[SizeY, SizeX];
            Queue<Vector2Int> _queue = new Queue<Vector2Int>();
            int cnt = 0;
            Vector2Int dest = CellToArrayPos(destPos);

            for (int i = 0; i < SizeY; i++)
            {
                for (int j = 0; j < SizeX; j++)
                    steps[i, j] = Int32.MaxValue;
            }

            Vector2Int _pos = CellToArrayPos(startPos);
            Vector2Int start = new Vector2Int(_pos.x, _pos.y);
            _queue.Enqueue(start);

            steps[_pos.y, _pos.x] = 0;
            while (_queue.Count > 0 && maxCount >= cnt)
            {
                Vector2Int node = _queue.Dequeue();
                for (int i = 0; i < 4; i++)
                {
                    int nextX = nx[i] + node.x;
                    int nextY = ny[i] + node.y;

                    Vector2Int nextPos = new Vector2Int(nextX, nextY);
                    if (IsInMap(nextPos, false) == true && steps[nextPos.y, nextPos.x] == Int32.MaxValue)
                    {
                        if (CanGo(nextPos, true, _checkObjects) == true)
                        {
                            steps[nextY, nextX] = steps[node.y, node.x] + 1;
                            _queue.Enqueue(nextPos);
                        }
                        else if (nextX == dest.x && nextY == dest.y)
                        {
                            steps[nextY, nextX] = steps[node.y, node.x] + 1;
                            break;
                        }
                        else
                            steps[nextY, nextX] = -1;
                    }
                }
                cnt++;
            }

            if (steps[dest.y, dest.x] != Int32.MaxValue)
                return TracePath(steps, dest);
            return null;
        }

        List<Vector2Int> TracePath(int[,] steps, Vector2Int dest)
        {
            List<Vector2Int> list = new List<Vector2Int>();

            int x = dest.x;
            int y = dest.y;
            Vector2Int cellPos = ArrayPosToCell(new Vector2Int(x, y));
            list.Add(new Vector2Int(cellPos.x, cellPos.y));

            int prevStepCnt = steps[y, x];
            while (prevStepCnt > 0)
            {
                for (int i = 0; i < 4; i++)
                {
                    int nextX = nx[i] + x;
                    int nextY = ny[i] + y;
                    if (steps[nextY, nextX] == prevStepCnt - 1)
                    {
                        cellPos = ArrayPosToCell(new Vector2Int(nextX, nextY));

                        list.Insert(0, new Vector2Int(cellPos.x, cellPos.y));
                        x = nextX;
                        y = nextY;
                        prevStepCnt--;
                        if (prevStepCnt == 0)
                            break;
                    }
                }
            }
            return list;
        }

        public bool IsInMap(Vector2Int pos, bool isCell = true)
        {
            Vector2Int _pos = pos;
            if (isCell == false)
                _pos = ArrayPosToCell(pos);
            int y = _pos.y;
            int x = _pos.x;
            return (xMin <= x && x <= xMax && yMin <= y && y <= yMax);
        }

        public GameObject Find(Vector2Int cellPos)
        {
            if (IsInMap(cellPos) == false)
                return null;
            Vector2Int dest = CellToArrayPos(cellPos);
            return _objects[dest.y, dest.x];
        }

        public bool ApplyLeave(GameObject gameObject)
        {
            if (gameObject.room == null)
                return false;
            if (gameObject.room._map == null)
                return false;

            PositionInfo posInfo = gameObject.PosInfo;
            if (IsInMap(new Vector2Int(posInfo.PosX, posInfo.PosY)) == false)
                return false;
            int x = posInfo.PosX - xMin;
            int y = yMax - posInfo.PosY;
            if (_objects[y, x] == gameObject)
                _objects[y, x] = null;

            return true;
        }

        public bool ApplyMove(GameObject gameObject, Vector2Int dest)
        {
            ApplyLeave(gameObject);

            if (gameObject.room == null)
                return false;
            if (gameObject.room._map == null)
                return false;

            if (CanGo(dest) == false)
                return false;
            int x = dest.x - xMin;
            int y = yMax - dest.y;
            _objects[y, x] = gameObject;
            gameObject.CellPos = dest;

            return true;
        }

        public bool CanGo(Vector2Int dest, bool arrayPos = false, bool checkObjects = false)
        {
            int y = dest.y;
            int x = dest.x;

            if (arrayPos == true)
            {
                Vector2Int cellPos = ArrayPosToCell(dest);
                y = cellPos.y;
                x = cellPos.x;
            }

            if (IsInMap(new Vector2Int(x, y)) == true)
            {
                x = x - xMin;
                y = yMax - y;
                return !_collision[y, x] && (!checkObjects || _objects[y, x] == null);
            }
            return false;
        }
        public void LoadMap(int mapId, string path = "../../../../../Common")
        {
            string mapName = string.Format("000", mapId);

            string text = File.ReadAllText($"{path}/Map_{mapName}.txt");

            StringReader reader = new StringReader(text);

            xMax = Int32.Parse(reader.ReadLine());
            xMin = Int32.Parse(reader.ReadLine());
            yMax = Int32.Parse(reader.ReadLine());
            yMin = Int32.Parse(reader.ReadLine());

            int xCount = xMax - xMin + 1;
            int yCount = yMax - yMin + 1;

            _collision = new bool[yCount, xCount];
            _objects = new GameObject[yCount, xCount];

            for (int y = 0; y < yCount; y++)
            {
                string line = reader.ReadLine();
                for (int x = 0; x < line.Length; x++)
                {
                    if (line[x] == '0')
                        _collision[y, x] = false;
                    else
                        _collision[y, x] = true;
                }
            }
        }

        public Vector2Int CellToArrayPos(Vector2Int pos)
        {
            int x = pos.x - xMin;
            int y = yMax - pos.y;
            return new Vector2Int(x, y);
        }

        public Vector2Int ArrayPosToCell(Vector2Int pos)
        {
            int x = xMin + pos.x;
            int y = yMax - pos.y;
            return new Vector2Int(x, y);
        }
    }

}
