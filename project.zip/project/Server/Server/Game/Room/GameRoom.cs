﻿using Google.Protobuf;
using Google.Protobuf.Protocol;
using Server.Job;
using System;
using System.Collections.Generic;
using System.Threading;

namespace Server.Game
{
    public class GameRoom : JobSerializer
    {
        public int roomId { get; set; }
        public Map _map = new Map();

        Dictionary<int, Player> _players = new Dictionary<int, Player>();
        Dictionary<int, Monster> _monsters = new Dictionary<int, Monster>();
        Dictionary<int, Projectile> _projectiles = new Dictionary<int, Projectile>();

        public void Update()
        {
            foreach (Monster m in _monsters.Values)
            {
                m.Update();
            }

            foreach (Projectile p in _projectiles.Values)
            {
                p.Update();
            }

            Flush();
        }

        public void Init(int mapId)
        {
            _map.LoadMap(mapId);

            Monster monster = ObjectManager.Instance.Add<Monster>();
            monster.CellPos = new Vector2Int(5, 5);
            EnterGame(monster);
        }

        public void EnterGame(GameObject gameObject)
        {
            if (gameObject == null)
                return;

            switch (gameObject.type)
            {
                case GameObjectType.Player:
                    Player player = gameObject as Player;
                    _players.Add(gameObject.id, player);
                    player.room = this;
                    _map.ApplyMove(player, new Vector2Int(player.PosInfo.PosX, player.PosInfo.PosY));

                    // casts entered each playerinfo to new player
                    S_EnterGame enterPacket = new S_EnterGame();
                    enterPacket.Player = player.Info;
                    player.session.Send(enterPacket);

                    S_Spawn _spawnPacket = new S_Spawn();
                    foreach (Player p in _players.Values)
                    {
                        if (p != player)
                            _spawnPacket.Objects.Add(p.Info);
                    }

                    foreach (Monster m in _monsters.Values)
                    {
                        _spawnPacket.Objects.Add(m.Info);
                    }

                    foreach (Projectile p in _projectiles.Values)
                    {
                        _spawnPacket.Objects.Add(p.Info);
                    }

                    player.session.Send(_spawnPacket);
                    break;
                case GameObjectType.Monster:
                    Monster monster = gameObject as Monster;
                    _monsters.Add(gameObject.id, monster);
                    monster.room = this;

                    _map.ApplyMove(monster, new Vector2Int(monster.CellPos.x, monster.CellPos.y));

                    break;
                case GameObjectType.Projectile:
                    Projectile projectile = gameObject as Projectile;
                    _projectiles.Add(gameObject.id, projectile);
                    projectile.room = this;
                    break;
            }

            // broadcasts entered new playerInfo to each player
            S_Spawn spawnPacket = new S_Spawn();
            spawnPacket.Objects.Add(gameObject.Info);

            foreach (Player p in _players.Values)
            {
                if (p.id != gameObject.id)
                    p.session.Send(spawnPacket);
            }
        }
        public void LeaveGame(int objectId)
        {
            GameObjectType type = ObjectManager.Instance.GetGameObjectTypeById(objectId);

            switch (type)
            {
                case GameObjectType.Player:
                    Player player = null;
                    if (!_players.Remove(objectId, out player))
                        return;
                    player.room._map.ApplyLeave(player);
                    player.room = null;

                    // casts leaved playerinfo to self
                    S_LeaveGame leavePacket = new S_LeaveGame();
                    player.session.Send(leavePacket);
                    break;
                case GameObjectType.Monster:
                    Monster monster = null;
                    if (!_monsters.Remove(objectId, out monster))
                        return;
                    monster.room._map.ApplyLeave(monster);
                    monster.room = null;
                    break;
                case GameObjectType.Projectile:
                    Projectile projectile = null;
                    if (!_projectiles.Remove(objectId, out projectile))
                        return;
                    projectile.room = null;
                    break;
            }

            // broadcasts leaved playerInfo to each player
            {
                S_Despawn deSpawnPacket = new S_Despawn();
                deSpawnPacket.ObjectIds.Add(objectId);

                foreach (Player p in _players.Values)
                {
                    if (p.id != objectId)
                        p.session.Send(deSpawnPacket);
                }
            }
        }
        public void HandleMove(Player player, C_Move movePacket)
        {
            if (player == null)
                return;

            PositionInfo posInfo = movePacket.PosInfo;
            ObjectInfo objectInfo = player.Info;

            if (posInfo.PosX != player.Info.PosInfo.PosX && posInfo.PosY != player.Info.PosInfo.PosY)
            {
                if (_map.CanGo(new Vector2Int(posInfo.PosX, posInfo.PosY)) == false)
                    return;
            }

            objectInfo.PosInfo.State = posInfo.State;
            objectInfo.PosInfo.MoveDir = posInfo.MoveDir;
            _map.ApplyMove(player, new Vector2Int(posInfo.PosX, posInfo.PosY));

            S_Move sMovePacket = new S_Move();
            sMovePacket.PosInfo = player.Info.PosInfo;
            sMovePacket.ObjectId = player.Info.ObjectId;
            Push(Broadcast, sMovePacket);
        }
        public void HandleSkill(Player player, SKillInfo info)
        {
            if (player == null)
                return;

            ObjectInfo pInfo = player.Info;
            if (pInfo.PosInfo.State != CharacterState.Idle && pInfo.PosInfo.State != CharacterState.Moving)
                return;

            pInfo.PosInfo.State = CharacterState.Skill;
            S_Skill sSkillPacket = new S_Skill() { SkillInfo = new SKillInfo() };
            sSkillPacket.PlayerId = pInfo.ObjectId;
            sSkillPacket.SkillInfo = info;
            Push(Broadcast, sSkillPacket);

            Skill skillData = null;
            if (DataManager.SkillDict.TryGetValue((int)info.SkillId, out skillData) == false)
                return;

            Vector2Int dest = player.GetOneBlockForward();
            switch (skillData.state)
            {
                case SkillState.Punch:
                    GameObject obj = _map.Find(dest);
                    if (obj != null)
                    {
                        Skill data = null;
                        if (DataManager.SkillDict.TryGetValue((int)info.SkillId, out data))
                        {
                            obj.OnDamaged(player, data.damage);
                        }
                    }
                    break;
                case SkillState.Projectile:
                    if (_map.CanGo(dest, false, true) == false)
                        return;

                    Arrow arrow = ObjectManager.Instance.Add<Arrow>();
                    arrow.Owner = player;
                    arrow.Data = skillData;
                    arrow.Info.PosInfo.PosX = dest.x;
                    arrow.Info.PosInfo.PosY = dest.y;
                    arrow.Info.PosInfo.State = CharacterState.Moving;
                    arrow.Info.PosInfo.MoveDir = player.PosInfo.MoveDir;
                    arrow.speed = skillData._pInfo.speed;
                    Push(EnterGame, arrow);
                    break;
            }
        }
        public void Broadcast(IMessage packet)
        {
            foreach (Player p in _players.Values)
            {
                p.session.Send(packet);
            }
        }

        public Player FindPlayer(Func<GameObject, bool> condition)
        {
            foreach (Player p in _players.Values)
                if (condition(p)) return p;
            return null;
        }
    }
}
