﻿using System;
using Google.Protobuf.Protocol;

namespace Server.Game
{
    public class Arrow : Projectile
    {
        public GameObject Owner {  get; set; }
        long _nextMoveTicks = 0;
        public Arrow()
        {
            type = GameObjectType.Projectile;
        }
        public override void Update()
        {
            if (Data == null || Data._pInfo == null || Owner == null || room == null)
                return;
            if (_nextMoveTicks >= Environment.TickCount64)
                return;

            long tick = (long)(1000 / speed);
            _nextMoveTicks = Environment.TickCount64 + tick;

            Vector2Int dest = GetOneBlockForward();
            if (room._map.CanGo(dest, false, true) == true)
            {
                CellPos = dest;
                S_Move movePacket = new S_Move();
                movePacket.ObjectId = id;
                movePacket.PosInfo = PosInfo;
                room.Broadcast(movePacket);
            }
            else
            {
                GameObject obj = room._map.Find(dest);
                // 피격 판정
                if (obj != null)
                {
                    obj.OnDamaged(Owner, Data.damage);
                }
                room.Push(room.LeaveGame, id);
            }
        }
    }
}
