﻿using Google.Protobuf.Protocol;
using System;
using System.Collections.Generic;

namespace Server.Game
{
    public class ObjectManager
    {
        public static readonly ObjectManager Instance = new ObjectManager();

        object _lock = new object();
        Dictionary<int, Player> _players = new Dictionary<int, Player>();
        int _counter = 0;
        public int GenerateId(GameObject go)
        {
            lock (_lock)
            {
                return ((int)go.type << 24 | _counter++);
            }
        }

        public GameObjectType GetGameObjectTypeById(int id)
        {
            int type = ((int)id >> 24 & 0X7F);
            return (GameObjectType)type;
        }

        public T Add<T>() where T : GameObject, new()
        {
            T gameObject = new T();

            lock (_lock)
            {
                gameObject.id = GenerateId(gameObject);

                if (gameObject.type == GameObjectType.Player)
                {
                    _players.Add(gameObject.id, gameObject as Player);
                }
            }

            return gameObject;
        }

        public bool Remove(int objectId)
        {
            GameObjectType type = GetGameObjectTypeById(objectId);
            lock (_lock)
            {
                if (type == GameObjectType.Player)
                    return _players.Remove(objectId);
            }

            return false;
        }

        public Player Find(int objectId)
        {
            GameObjectType type = GetGameObjectTypeById(objectId);
            lock (_lock)
            {
                if (type == GameObjectType.Player)
                {
                    Player player = null;
                    if (_players.TryGetValue(objectId, out player))
                        return player;
                }
            }
            return null;
        }
    }
}
