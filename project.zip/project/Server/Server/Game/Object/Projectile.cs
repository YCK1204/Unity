﻿using System;
using Google.Protobuf.Protocol;

namespace Server.Game
{
    public class Projectile : GameObject
    {
        public Skill Data { get; set; }

        public Projectile()
        {
            type = GameObjectType.Projectile;
        }

        public virtual void Update() { }
    }
}
