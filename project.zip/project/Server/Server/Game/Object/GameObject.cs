﻿using Google.Protobuf.Protocol;
using System;

namespace Server.Game
{
    public class GameObject
    {
        public GameObjectType type { get; protected set; } = GameObjectType.None;

        public ObjectInfo Info { get; set; } = new ObjectInfo();

        public int id
        {
            get { return Info.ObjectId; }
            set { Info.ObjectId = value; }
        }
        public float hp
        {
            get { return stat.Hp; }
            set { stat.Hp = value; }
        }
        public Dir Dir
        {
            get { return PosInfo.MoveDir; }
            set { PosInfo.MoveDir = value; }
        }
        public float maxHp
        {
            get { return stat.MaxHp; }
            set { stat.MaxHp = value; }
        }
        public CharacterState State
        {
            get { return PosInfo.State; }
            set { PosInfo.State = value; }
        }
        public float speed
        {
            get { return stat.Speed; }
            set { stat.Speed = value; }
        }
        public PositionInfo PosInfo { get; private set; } = new PositionInfo();
        public StatInfo stat { get; private set; } = new StatInfo();
        public GameRoom room { get; set; }
        public GameObject()
        {
            Info.PosInfo = PosInfo;
            Info.StatInfo = stat;
        }
        public Vector2Int CellPos
        {
            get { return new Vector2Int(PosInfo.PosX, PosInfo.PosY); }
            set
            {
                PosInfo.PosX = value.x;
                PosInfo.PosY = value.y;
            }
        }
        public Vector2Int GetOneBlockForward()
        {
            return GetOneBlockForward(PosInfo.MoveDir);
        }
        public Vector2Int GetOneBlockForward(Dir dir)
        {
            Vector2Int destPos = CellPos;
            switch (dir)
            {
                case Dir.Down:
                    destPos += Vector2Int.down;
                    break;
                case Dir.Up:
                    destPos += Vector2Int.up;
                    break;
                case Dir.Left:
                    destPos += Vector2Int.left;
                    break;
                case Dir.Right:
                    destPos += Vector2Int.right;
                    break;
            }
            return destPos;
        }

        public virtual void Update()
        {

        }

        public virtual void UpdateIdle()
        {

        }

        public virtual void UpdateMoving()
        {

        }
        public virtual void UpdateSkill()
        {

        }
        public virtual void UpdateDead()
        {

        }

        public static Dir SetDirection(Vector2Int dest, Vector2Int cell)
        {
            if (dest.x < cell.x)
                return Dir.Left;
            else if (dest.x > cell.x)
                return Dir.Right;
            else if (dest.y < cell.y)
                return Dir.Down;
            else
                return Dir.Up;
        }
        public virtual void OnDamaged(GameObject attacker, float damage)
        {
            if (room == null)
                return;

            hp = Math.Max(hp - damage, 0);

            S_ChangeHp changePacket = new S_ChangeHp();
            changePacket.ObjectId = id;
            changePacket.Hp = hp;

            room.Broadcast(changePacket);

            if (hp == 0)
            {
                OnDead(attacker);
            }
        }

        protected virtual void OnDead(GameObject attacker)
        {
            if (room == null)
                return;

            S_Dead deadPacket = new S_Dead();
            deadPacket.ObjectId = id;
            deadPacket.AttackerId = attacker.id;

            GameRoom _room = room;

            _room.Broadcast(deadPacket);

            _room.Push(_room.LeaveGame, id);

            _room.Push(() =>
            {
                stat.Hp = maxHp;
                PosInfo.PosX = 0;
                PosInfo.PosY = 0;
                PosInfo.State = CharacterState.Idle;
                PosInfo.MoveDir = Dir.Down;
            });

            _room.Push(_room.EnterGame, this);
        }
    }
}
