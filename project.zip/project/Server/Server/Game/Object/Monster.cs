﻿using System;
using System.Collections;
using System.Collections.Generic;
using Google.Protobuf.Protocol;

namespace Server.Game
{
    public class Monster : GameObject
    {
        public Monster()
        {
            type = GameObjectType.Monster;

            stat.Hp = 100;
            stat.MaxHp = 100;
            stat.Speed = 10.0f;
            stat.Level = 1;

            State = CharacterState.Idle;
        }

        public override void Update()
        {
            switch (State)
            {
                case CharacterState.Idle:
                    UpdateIdle();
                    break;
                case CharacterState.Moving:
                    UpdateMoving();
                    break;
                case CharacterState.Skill:
                    UpdateSkill();
                    break;
                case CharacterState.Dead:
                    UpdateDead();
                    break;
            }
        }

        long nextTick = 0;
        int _searchCellDist = 10;
        Player _target;
        public override void UpdateIdle()
        {
            if (Environment.TickCount64 < nextTick)
                return;
            nextTick = Environment.TickCount64 + 1000;

            _target = room.FindPlayer(p =>
            {
                Vector2Int dist = p.CellPos - CellPos;
                return dist.cellDistFromZero <= _searchCellDist;
            });

            if (_target == null)
                return;

            State = CharacterState.Moving;
        }

        long _nextMoveTick = 0;
        int _chaseCellDist = 20;
        float _skillrange = 1;
        public override void UpdateMoving()
        {
            if (Environment.TickCount64 < _nextMoveTick)
                return;
            int moveTick = (int)(1000 / speed);
            _nextMoveTick = Environment.TickCount64 + moveTick;

            if (_target == null || _target.room != room)
            {
                _target = null;
                State = CharacterState.Idle;
                BroadcastMove();
                return;
            }

            Vector2Int dist = _target.CellPos - CellPos;
            int _dist = dist.cellDistFromZero;
            if (_dist == 0 || _dist > _searchCellDist)
            {
                _target = null;
                State = CharacterState.Idle;
                BroadcastMove();
                return;
            }

            List<Vector2Int> path = room._map.FindPath(CellPos, _target.CellPos, true, _chaseCellDist * 10);
            if (path == null)
            {
                _target = null;
                State = CharacterState.Idle;
                BroadcastMove();
                return;
            }

            if (path.Count < 3)
            {
                if (_dist <= _skillrange || dist.x == 0 || dist.y == 0)
                {
                    State = CharacterState.Skill;
                    return;
                }
                else
                {
                    _target = null;
                    State = CharacterState.Idle;
                    BroadcastMove();
                    return;
                }
            }

            Dir = SetDirection(path[1], CellPos);
            room._map.ApplyMove(this, path[1]);
            BroadcastMove();
        }

        long _coolTick = 0;
        public override void UpdateSkill()
        {
            if (_coolTick == 0)
            {
                if (_target == null || _target.room != room || _target.hp == 0)
                {
                    _target = null;
                    State = CharacterState.Moving;
                    return;
                }

                Vector2Int dist = _target.CellPos - CellPos;
                int _dist = dist.cellDistFromZero;
                bool canUseSkill = (_dist <= _skillrange && (dist.x == 0 || dist.y == 0));
                if (canUseSkill == false)
                {
                    State = CharacterState.Moving;
                    return;
                }

                Dir dir = SetDirection(_target.CellPos, CellPos);
                if (Dir != dir)
                {
                    Dir = dir;
                    BroadcastMove();
                }

                Skill _skillData = null;
                DataManager.SkillDict.TryGetValue(1, out _skillData);

                _target.OnDamaged(this, _skillData.damage);

                S_Skill skillPacket = new S_Skill() { SkillInfo = new SKillInfo() };
                skillPacket.PlayerId = id;
                skillPacket.SkillInfo.SkillId = SkillState.Punch;
                room.Broadcast(skillPacket);

                int coolTick = (int)(1000 * _skillData.cooldown);
                _coolTick = Environment.TickCount64 + coolTick;
            }

            if (_coolTick > Environment.TickCount64)
                return;
            _coolTick = 0;
        }

        void BroadcastMove()
        {
            S_Move movePacket = new S_Move();
            movePacket.ObjectId = id;
            movePacket.PosInfo = PosInfo;
            room.Broadcast(movePacket);
        }
    }
}
