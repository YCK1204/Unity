﻿using Google.Protobuf.Protocol;
using System;

namespace Server.Game
{
    public class Player : GameObject
    {
        public ClientSession session { get; set; }

        public Player()
        {
            type = GameObjectType.Player;
            speed = 20;
            hp = 100f;
            maxHp = 100f;
        }

        public override void OnDamaged(GameObject attacker, float damage)
        {
            base.OnDamaged(attacker, damage);
        }
    }
}
