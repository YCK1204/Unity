using UnityEngine;
using UnityEngine.Tilemaps;
using System.IO;

#if UNITY_EDITOR
using UnityEditor;
#endif
public class MapEditor
{
#if UNITY_EDITOR

    [MenuItem("Tools/Generate")]
    private static void GenerateByPath()
    {
        GenerateMap("Assets/Resources/Edit");
        GenerateMap("../Desktop/Common");
    }

    private static void GenerateMap(string path)
    {
        GameObject[] objs = Resources.LoadAll<GameObject>("Prefabs/Map");

        foreach (GameObject obj in objs)
        {
            GameObject t = Util.FindChild(obj, "Tilemap_Collision", true);
            if (t == null) continue;

            Tilemap tilemap = t.GetComponent<Tilemap>();
            if (tilemap == null) continue;
            using (StreamWriter s = new StreamWriter($"{path}/{obj.name}.txt"))
            {
                int xMax = tilemap.cellBounds.xMax - 1;
                int xMin = tilemap.cellBounds.xMin;
                int yMax = tilemap.cellBounds.yMax - 1;
                int yMin = tilemap.cellBounds.yMin;
                s.WriteLine(xMax);
                s.WriteLine(xMin);
                s.WriteLine(yMax);
                s.WriteLine(yMin);
                for (int y = yMax; y >= yMin; y--)
                {
                    for (int x = xMin; x <= xMax; x++)
                    {
                        if (tilemap.GetTile(new Vector3Int(x, y, 0)) != null)
                        {
                            s.Write("1");
                        }
                        else
                        {
                            s.Write("0");
                        }
                    }
                    s.WriteLine();
                }
            }
        }
    }
#endif
}
