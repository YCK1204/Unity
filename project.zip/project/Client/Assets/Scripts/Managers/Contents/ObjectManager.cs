using Google.Protobuf.Protocol;
using System;
using System.Collections.Generic;
using UnityEngine;

public class ObjectManager
{
    public MyPlayerController MyPlayer { get; set; } = null;
    Dictionary<int, GameObject> _objects = new Dictionary<int, GameObject>();
    public GameObjectType GetGameObjectTypeById(int id)
    {
        int type = ((int)id >> 24 & 0X7F);
        return (GameObjectType)type;
    }
    public void Add(ObjectInfo info, bool myPlayer = false)
    {
        GameObjectType type = GetGameObjectTypeById(info.ObjectId);

        switch (type)
        {
            case GameObjectType.Player:
                GameObject go = null;
                if (_objects.TryGetValue(info.ObjectId, out go))
                    return;

                if (myPlayer == true)
                {
                    GameObject player = Managers.Resource.Instantiate("MyPlayer");
                    player.name = info.Name;
                    Add(info.ObjectId, player);

                    MyPlayer = player.GetComponent<MyPlayerController>();
                    MyPlayer.id = info.ObjectId;
                    MyPlayer.PosInfo = info.PosInfo;
                    MyPlayer.Stat = info.StatInfo;
                    MyPlayer.SyncPos();
                }
                else
                {
                    GameObject player = Managers.Resource.Instantiate("Player");
                    player.name = info.Name;
                    Add(info.ObjectId, player);

                    PlayerController pc = player.GetComponent<PlayerController>();
                    pc.id = info.ObjectId;
                    pc.PosInfo = info.PosInfo;
                    pc.Stat = info.StatInfo;
                    pc.SyncPos();
                }
                break;
            case GameObjectType.Monster:
                GameObject enemy = Managers.Resource.Instantiate("Enemy");
                enemy.name = info.Name;
                Add(info.ObjectId, enemy);

                EnemyController mc = enemy.GetComponent<EnemyController>();
                mc.id = info.ObjectId;
                mc.PosInfo = info.PosInfo;
                mc.Stat = info.StatInfo;
                mc.SyncPos();
                break;
            case GameObjectType.Projectile:
                GameObject arrow = Managers.Resource.Instantiate("Arrow");
                ArrowController ac = arrow.GetComponent<ArrowController>();
                Add(info.ObjectId, arrow);
                ac.name = "Arrow";

                ac.id = info.ObjectId;
                ac.PosInfo = info.PosInfo;
                ac.Stat = info.StatInfo;
                ac.SyncPos();
                break;
        }
    }
    public GameObject FindById(int id)
    {
        GameObject obj = null;
        _objects.TryGetValue(id, out obj);

        return obj;
    }
    public void Add(int id, GameObject go)
    {
        BaseController bc = go.GetComponent<BaseController>();

        if (bc != null)
            _objects.Add(id, go);
    }


    public void Remove(int id)
    {
        GameObject go = null;
        _objects.TryGetValue(id, out go);
        if (go != null)
        {
            Managers.Resource.Destroy(go);
            _objects.Remove(id);
        }
    }

    public void Clear()
    {
        foreach (GameObject go in _objects.Values)
        {
            Managers.Resource.Destroy(go);
        }
        _objects.Clear();
        MyPlayer = null;
    }

    public GameObject FindObject(Vector3Int cellPos, bool arrayPos = false)
    {
        Vector3Int cell = cellPos;
        if (arrayPos == true)
            cell = Managers.Map.ArrayPosToCell(cellPos);

        foreach (GameObject go in _objects.Values)
        {
            BaseController bc = go.GetComponent<BaseController>();

            if (bc != null)
            {
                if (bc.CellPos == cell)
                    return go;
            }
        }

        return null;
    }

    public GameObject Find(Func<GameObject, bool> condition)
    {
        foreach (GameObject go in _objects.Values)
            if (condition.Invoke(go) == true) return go;
        return null;
    }
}
