using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
public class MapManager
{
    public Grid CurrentGrid { get; set; }

    public int xMax { get; set; }
    public int xMin { get; set; }
    public int yMax { get; set; }
    public int yMin { get; set; }

    int SizeX { get { return xMax - xMin + 1; } }
    int SizeY { get { return yMax - yMin + 1; } }

    int[] nx = { -1, 0, 1, 0 };
    int[] ny = { 0, 1, 0, -1 };

    public bool[,] _collision;

    public bool IsInMap(Vector3Int pos)
    {
        Vector3Int _pos = ArrayPosToCell(pos);
        int y = _pos.y;
        int x = _pos.x;
        return (xMin <= x && x <= xMax && yMin <= y && y <= yMax);
    }

    public bool CanGo(Vector3Int dest, bool arrayPos = false)
    {
        int y = dest.y;
        int x = dest.x;

        if (arrayPos == true)
        {
            Vector3Int cellPos = ArrayPosToCell(dest);
            y = cellPos.y;
            x = cellPos.x;
        }

        if (xMin <= x && x <= xMax && yMin <= y && y <= yMax)
        {
            x = x - xMin;
            y = yMax - y;
            return !_collision[y, x];
        }
        return false;
    }
    public void LoadMap(int mapId)
    {
        DestroyMap();

        string mapName = string.Format("000", mapId);

        GameObject map = Managers.Resource.Load<GameObject>($"Prefabs/Map/Map_{mapName}");
        if (map != null)
        {
            GameObject go = Managers.Resource.Instantiate($"Map/Map_{mapName}");
            go.name = "Map";

            GameObject collision = Util.FindChild(go, "Tilemap_Collision", true);
            if (collision != null)
            {
                collision.SetActive(false);
            }
            CurrentGrid = map.GetComponent<Grid>();

            TextAsset text = Managers.Resource.Load<TextAsset>($"Edit/Map_{mapName}");
            StringReader reader = new StringReader(text.text);

            xMax = Int32.Parse(reader.ReadLine());
            xMin = Int32.Parse(reader.ReadLine());
            yMax = Int32.Parse(reader.ReadLine());
            yMin = Int32.Parse(reader.ReadLine());

            int xCount = xMax - xMin + 1;
            int yCount = yMax - yMin + 1;

            _collision = new bool[yCount, xCount];

            for (int y = 0; y < yCount; y++)
            {
                string line = reader.ReadLine();
                for (int x = 0; x < line.Length; x++)
                {
                    if (line[x] == '0')
                        _collision[y, x] = false;
                    else
                        _collision[y, x] = true;
                }
            }
        }
        else
            Debug.LogError($"Cannot found Map_{mapName}");
    }

    public Vector3Int CellToArrayPos(Vector3Int pos)
    {
        int x = pos.x - xMin;
        int y = yMax - pos.y;
        return new Vector3Int(x, y, pos.z);
    }

    public Vector3Int ArrayPosToCell(Vector3Int pos)
    {
        int x = xMin + pos.x;
        int y = yMax - pos.y;
        return new Vector3Int(x, y, pos.z);
    }

    public void DestroyMap()
    {
        GameObject map = GameObject.Find("Map");

        if (map != null)
        {
            GameObject.Destroy(map);
            CurrentGrid = null;
        }
    }
}
