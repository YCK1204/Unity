using Google.Protobuf.Protocol;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Define;

public class EnemyController : CreatureController
{
    //Vector3Int destPos;
    
    //IEnumerator CoPatrol()
    //{
    //    System.Random rand = new System.Random();
    //    yield return new WaitForSeconds(rand.Next(1, 4));
    //    for (int i = 0; i < 5; i++)
    //    {
    //        int x = rand.Next(-5, 5) + CellPos.x;
    //        int y = rand.Next(-5, 5) + CellPos.y;

    //        Vector3Int randPos = new Vector3Int(x, y, 0);
    //        if (Managers.Map.CanGo(randPos) == true && Managers.Object.FindObject(randPos) == null)
    //        {
    //            destPos = randPos;
    //            State = CharacterState.Moving;
    //            yield break;
    //        }
    //    }
    //    State = CharacterState.Idle;
    //}
    //bool IsOnStraightLine(MapManager.Node node)
    //{
    //    if (CellPos.x != node.x && CellPos.y != node.y)
    //        return false;
    //    if (Mathf.Abs(CellPos.x - node.x) > _shotRange || Mathf.Abs(CellPos.y - node.y) > _shotRange)
    //        return false;
    //    return true;
    //}
    //bool IsClearPath(MapManager.Node node)
    //{
    //    int x, endX;
    //    int y, endY;
    //    bool IsOnStrightX;
    //    if (CellPos.x == node.x)
    //    {
    //        y = CellPos.y < node.y ? CellPos.y : node.y;
    //        endY = CellPos.y < node.y ? node.y : CellPos.y;
    //        x = CellPos.x;
    //        endX = node.x;
    //        IsOnStrightX = true;
    //    }
    //    else
    //    {
    //        x = CellPos.x < node.x ? CellPos.x : node.x;
    //        endX = CellPos.x < node.x ? node.x : CellPos.x;
    //        y = CellPos.y;
    //        endY = node.y;
    //        IsOnStrightX = false;
    //    }

    //    Vector3Int dest;
    //    if (IsOnStrightX)
    //    {
    //        for (; y < endY; y++)
    //        {
    //            dest = new Vector3Int(x, y, 0);
    //            if (Managers.Map.CanGo(dest) == false)
    //                return false;
    //        }
    //    }
    //    else
    //    {
    //        for (; x < endX; x++)
    //        {
    //            dest = new Vector3Int(x, y, 0);
    //            if (Managers.Map.CanGo(dest) == false)
    //                return false;
    //        }
    //    }
    //    return true;
    //}
}
