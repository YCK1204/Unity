﻿using Google.Protobuf.Protocol;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using static Define;

public class BaseController : MonoBehaviour
{
    #region Variables
    protected bool _updated = false;
    PositionInfo _posInfo = new PositionInfo();
    StatInfo _statInfo = new StatInfo();
    public int id { get; set; }
    #endregion

    protected float Speed
    {
        get { return Stat.Speed; }
        set { _statInfo.Speed = value; }
    }
    public StatInfo Stat
    {
        get { return _statInfo; }
        set
        {
            if (_statInfo.Equals(value))
                return;

            _statInfo.Hp = value.Hp;
            _statInfo.MaxHp = value.MaxHp;
            _statInfo.Speed = value.Speed;
        }
    }
    public Vector3Int CellPos
    {
        get { return new Vector3Int(PosInfo.PosX, PosInfo.PosY, 0); }
        set
        {
            if (value.x == PosInfo.PosX && value.y == PosInfo.PosY)
                return;

            PosInfo.PosX = value.x;
            PosInfo.PosY = value.y;
            _updated = true;
        }
    }
    public virtual PositionInfo PosInfo
    {
        get { return _posInfo; }
        set
        {
            if (_posInfo.Equals(value))
                return;
            _posInfo = value;
        }
    }
    public virtual CharacterState State
    {
        get { return PosInfo.State; }
        set
        {
            if (PosInfo.State != value)
            {
                PosInfo.State = value;
                _updated = true;
            }
        }
    }
    public virtual Dir Dir
    {
        get { return PosInfo.MoveDir; }
        set
        {
            if (value != PosInfo.MoveDir)
            {
                PosInfo.MoveDir = value;

                _updated = true;
            }
        }
    }
    void Start()
    {
        Init();
    }
    protected virtual void Init()
    {
        transform.position = Managers.Map.CurrentGrid.CellToWorld(CellPos) + new Vector3(0.5f, 0.5f);
    }

    public void SyncPos()
    {
        Vector3Int dest = new Vector3Int(CellPos.x, CellPos.y, 0);
        transform.position = dest + new Vector3(0.5f, 0.5f);
    }
    void Update()
    {
        UpdateController();
    }
    protected virtual void UpdateController()
    {
        switch (State)
        {
            case CharacterState.Idle:
                UpdateIdle();
                break;
            case CharacterState.Moving:
                UpdateMoving();
                break;
            case CharacterState.Skill:
                break;
            case CharacterState.Dead:
                break;
        }
    }
    protected virtual void UpdateMoving()
    {
        Vector3 cellpos = Managers.Map.CurrentGrid.CellToWorld(CellPos) + new Vector3(0.5f, 0.5f);
        Vector3 dest = cellpos - transform.position;

        if (dest.magnitude < Speed * Time.deltaTime)
        {
            transform.position = cellpos;
            MoveToNextPos();
        }
        else
        {
            State = CharacterState.Moving;
            transform.position += Speed * Time.deltaTime * dest.normalized;
        }
    }

    protected virtual void MoveToNextPos()
    {
    }

    protected virtual void UpdateIdle()
    {
    }
    protected Vector3Int GetOneBlockForward(Vector3Int cellPos)
    {
        Vector3Int destPos = cellPos;
        switch (Dir)
        {
            case Dir.Down:
                destPos += Vector3Int.down;
                break;
            case Dir.Up:
                destPos += Vector3Int.up;
                break;
            case Dir.Left:
                destPos += Vector3Int.left;
                break;
            case Dir.Right:
                destPos += Vector3Int.right;
                break;
        }
        return destPos;
    }
    protected virtual void CheckUpdated()
    {

    }
}
