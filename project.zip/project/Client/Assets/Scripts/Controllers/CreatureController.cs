using Google.Protobuf.Protocol;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using static Define;

public class CreatureController : BaseController
{
    #region Variables
    protected bool isInit = false;
    protected Slider _hpBar;
    protected Animator _animator;
    protected SpriteRenderer _renderer;
    protected Coroutine _coSkill = null;
    protected SkillState _skillState = SkillState.None;
    protected Coroutine _coCoolTime = null;
    protected bool _keyPressed = false;
    #endregion
    public SkillState SkillState
    {
        get { return _skillState; }
        set
        {
            if (value != _skillState)
            {
                _skillState = value;
                UpdateAnimation();
            }
        }
    }

    public override PositionInfo PosInfo
    {
        get { return base.PosInfo; }
        set
        {
            base.PosInfo = value;
            UpdateAnimation();
        }
    }
    public override CharacterState State
    {
        get { return PosInfo.State; }
        set
        {
            base.State = value;
            UpdateAnimation();
        }
    }
    public override Dir Dir
    {
        get { return base.PosInfo.MoveDir; }
        set
        {
            base.PosInfo.MoveDir = value;
            UpdateAnimation();
        }
    }
    void InitHpBar()
    {
        Slider slider = Util.FindChild<Slider>(gameObject, "Slider", true);
        if (slider != null)
        {
            _hpBar = slider;
        }
    }
    public void SetHpBar(float ratio)
    {
        _hpBar.value = ratio;
    }
    protected override void Init()
    {
        base.Init();
        _animator = GetComponent<Animator>();
        _renderer = GetComponent<SpriteRenderer>();
        _animator.Play("IDLE_FRONT");
        InitHpBar();
        SetHpBar(Stat.Hp / Stat.MaxHp);
        isInit = true;
    }
    public virtual void OnDead()
    {
        State = CharacterState.Dead;

        GameObject go = Managers.Resource.Instantiate("DeathEffect");
        go.transform.position = transform.position;
        GameObject.Destroy(go, 0.5f);
    }
    public virtual void OnDamaged()
    {
        float ratio = Stat.Hp / Stat.MaxHp;
        SetHpBar(ratio);
    }
    protected virtual void UpdateAnimation()
    {
        if (isInit == false)
            return;
        _renderer.flipX = false;
        if (State == CharacterState.Idle)
        {
            switch (Dir)
            {
                case Dir.Up:
                    _animator.Play("IDLE_BACK");
                    break;
                case Dir.Down:
                    _animator.Play("IDLE_FRONT");
                    break;
                case Dir.Left:
                    _animator.Play("IDLE_SIDE");
                    _renderer.flipX = true;
                    break;
                case Dir.Right:
                    _animator.Play("IDLE_SIDE");
                    break;
            }
        }
        else if (State == CharacterState.Skill)
        {
            if (SkillState == SkillState.Punch)
            {
                switch (Dir)
                {
                    case Dir.Up:
                        _animator.Play("ATTACK_BACK");
                        break;
                    case Dir.Down:
                        _animator.Play("ATTACK_FRONT");
                        break;
                    case Dir.Left:
                        _animator.Play("ATTACK_SIDE");
                        _renderer.flipX = true;
                        break;
                    case Dir.Right:
                        _animator.Play("ATTACK_SIDE");
                        break;
                }
            }
            else if (SkillState == SkillState.Projectile)
            {
                switch (Dir)
                {
                    case Dir.Up:
                        _animator.Play("ATTACK_WEAPON_BACK");
                        break;
                    case Dir.Down:
                        _animator.Play("ATTACK_WEAPON_FRONT");
                        break;
                    case Dir.Left:
                        _animator.Play("ATTACK_WEAPON_SIDE");
                        _renderer.flipX = true;
                        break;
                    case Dir.Right:
                        _animator.Play("ATTACK_WEAPON_SIDE");
                        break;
                }
            }
        }
        else
        {
            switch (Dir)
            {
                case Dir.Up:
                    _animator.Play("WALK_BACK");
                    break;
                case Dir.Down:
                    _animator.Play("WALK_FRONT");
                    break;
                case Dir.Left:
                    _animator.Play("WALK_SIDE");
                    _renderer.flipX = true;
                    break;
                case Dir.Right:
                    _animator.Play("WALK_SIDE");
                    break;
            }
        }
    }
    public virtual void StartCoroutineController(string name, CoState coState)
    {
        if (coState == CoState.Skill && _coSkill == null)
        {
            State = CharacterState.Skill;
            _coSkill = StartCoroutine(name);
        }
    }
    protected virtual void StopCoroutineController(string name)
    {
        StopCoroutine(name);
    }

    protected virtual IEnumerator CoAttack()
    {
        SkillState = SkillState.Punch;

        yield return new WaitForSeconds(0.5f);
        State = CharacterState.Moving;
        CheckUpdated();
        _coSkill = null;
    }
    protected virtual IEnumerator CoAttackWeapon()
    {
        SkillState = SkillState.Projectile;

        yield return new WaitForSeconds(0.2f);
        State = CharacterState.Moving;
        CheckUpdated();
        _coSkill = null;
    }
    protected virtual IEnumerator CoInputCoolTime(float time)
    {
        yield return new WaitForSeconds(time);
        _coCoolTime = null;
    }
}
