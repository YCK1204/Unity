using Google.Protobuf.Protocol;
using UnityEngine;

public class PlayerController : CreatureController
{
    protected override void UpdateIdle()
    {
        if (_keyPressed)
        {
            State = CharacterState.Moving;
            return;
        }
    }
}
