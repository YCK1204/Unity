using UnityEngine;
using Google.Protobuf.Protocol;
using static Define;
public class MyPlayerController : CreatureController
{
    bool _skillKeyPressed = false;
    protected override void Init()
    {
        base.Init();
    }
    protected override void UpdateController()
    {
        switch (State)
        {
            case CharacterState.Idle:
            case CharacterState.Moving:
                GetInputDir();
                GetInputSkill();
                break;
        }

        base.UpdateController();
    }
    void LateUpdate()
    {
        Camera.main.transform.position = new Vector3(transform.position.x, transform.position.y, -10);
    }

    void GetInputDir()
    {
        if (_coCoolTime != null)
            return;

        _keyPressed = true;
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
            Dir = Dir.Up;
        else if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
            Dir = Dir.Down;
        else if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
            Dir = Dir.Left;
        else if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
            Dir = Dir.Right;
        else
            _keyPressed = false;
    }

    protected override void UpdateIdle()
    {
        if (_keyPressed)
        {
            State = CharacterState.Moving;
            CheckUpdated();
            return;
        }
    }

    void GetInputSkill()
    {
        if (_coCoolTime != null)
            return;


        C_Skill skillPack = new C_Skill() { SkillInfo = new SKillInfo() };

        _skillKeyPressed = true;
        if (Input.GetKey(KeyCode.Z))
            skillPack.SkillInfo.SkillId = SkillState.Punch;
        else if (Input.GetKey(KeyCode.J))
            skillPack.SkillInfo.SkillId = SkillState.Projectile;
        else
        {
            _skillKeyPressed = false;
            return;
        }

        Managers.Network.Send(skillPack);
        _coCoolTime = StartCoroutine("CoInputCoolTime", 0.2f);
    }
    protected override void MoveToNextPos()
    {
        if (_skillKeyPressed)
            return;

        if (!_keyPressed)
        {
            State = CharacterState.Idle;
            CheckUpdated();
            return;
        }

        Vector3Int destPos = CellPos;

        switch (Dir)
        {
            case Dir.Down:
                destPos += Vector3Int.down;
                break;
            case Dir.Up:
                destPos += Vector3Int.up;
                break;
            case Dir.Left:
                destPos += Vector3Int.left;
                break;
            case Dir.Right:
                destPos += Vector3Int.right;
                break;
        }

        if (Managers.Map.CanGo(destPos) == true)
        {
            if (Managers.Object.FindObject(destPos) == null)
            {
                CellPos = destPos;
            }
        }

        CheckUpdated();
    }

    protected override void CheckUpdated()
    {
        if (_updated)
        {
            C_Move movePacket = new C_Move();
            movePacket.PosInfo = PosInfo;
            Managers.Network.Send(movePacket);
            _updated = false;
        }
    }
}
