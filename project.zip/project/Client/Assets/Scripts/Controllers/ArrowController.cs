using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Define;
using Google.Protobuf.Protocol;

public class ArrowController : BaseController
{
    protected override void Init()
    {
        switch (Dir)
        {
            case Dir.Down:
                transform.rotation = Quaternion.Euler(0, 0, -180f);
                break;
            case Dir.Right:
                transform.rotation = Quaternion.Euler(0, 0, -90f);
                break;
            case Dir.Left:
                transform.rotation = Quaternion.Euler(0, 0, -270f);
                break;
        }
    }
}
