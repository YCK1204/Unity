﻿using Google.Protobuf;
using Google.Protobuf.Protocol;
using ServerCore;
using UnityEngine;

class PacketHandler
{
	public static void S_EnterGameHandler(PacketSession session, IMessage packet)
	{
		S_EnterGame player = packet as S_EnterGame;
        Managers.Object.Add(player.Player, true);
	}
	public static void S_LeaveGameHandler(PacketSession session, IMessage packet)
	{
        S_LeaveGame leavetPacket = packet as S_LeaveGame;
        Managers.Object.Clear();
	}
    public static void S_SpawnHandler(PacketSession session, IMessage packet)
    {
        S_Spawn spawnGamePacket = packet as S_Spawn;
        
        foreach (ObjectInfo info in spawnGamePacket.Objects)
            Managers.Object.Add(info, false);
    }
    public static void S_DespawnHandler(PacketSession session, IMessage packet)
    {
        S_Despawn despawnGamePacket = packet as S_Despawn;
        foreach (int id in despawnGamePacket.ObjectIds)
            Managers.Object.Remove(id);
    }

    public static void S_MoveHandler(PacketSession session, IMessage packet)
    {
        S_Move moveGamePacket = packet as S_Move;

        GameObject go = Managers.Object.FindById(moveGamePacket.ObjectId);

        if (go == null)
            return;

        BaseController bc = go.GetComponent<BaseController>();
        if (bc == null)
            return;
        
        bc.PosInfo = moveGamePacket.PosInfo;
    }

    public static void S_SkillHandler(PacketSession session, IMessage packet)
    {
        S_Skill skillPacket = packet as S_Skill;

        GameObject go = Managers.Object.FindById(skillPacket.PlayerId);

        if (go == null)
            return;

        CreatureController cc = go.GetComponent<CreatureController>();
        if (cc == null)
            return;

        string coName = "";
        switch (skillPacket.SkillInfo.SkillId)
        {
            case SkillState.Punch:
                coName = "CoAttack"; 
                break;
            case SkillState.Projectile:
                coName = "CoAttackWeapon";
                break;
        }

        cc.StartCoroutineController(coName, Define.CoState.Skill);
    }

    public static void S_ChangeHpHandler(PacketSession session, IMessage packet)
    {
        S_ChangeHp changeHpPacket = packet as S_ChangeHp;

        GameObject go = Managers.Object.FindById(changeHpPacket.ObjectId);

        if (go == null)
            return;

        CreatureController cc = go.GetComponent<CreatureController>();
        if (cc == null)
            return;

        cc.Stat.Hp = changeHpPacket.Hp;
        cc.OnDamaged();
    }

    public static void S_DeadHandler(PacketSession session, IMessage packet)
    {
        S_Dead deadPacket = packet as S_Dead;

        GameObject go = Managers.Object.FindById(deadPacket.ObjectId);

        if (go == null)
            return;

        CreatureController cc = go.GetComponent<CreatureController>();
        if (cc == null)
            return;

        cc.Stat.Hp = 0;
        cc.OnDead();
    }
}
